package com.example.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.hamcrest.Matchers.hasSize;

import com.example.test.controller.Employee;
import com.example.test.controller.EmployeeController;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

//@SpringBootTest
//@WebMvcTest(EmployeeController.class)
@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith(SpringExtension.class)
class TestApplicationTests {

	@Autowired
	MockMvc mockMvc;

	@Test
	void contextLoads() {
	}

	ObjectMapper objectMapper = new ObjectMapper();

	@Test
	public void test() throws Exception {
		mockMvc.perform(get("/api/v1/customer")).andExpect(status().isOk())
				.andExpect(jsonPath("$.empName").value("Nishant"));

	}

	@Test
	public void test1() throws Exception {
		Employee employee = new Employee();
		employee.setEmpId(2);
		employee.setEmpName("Nishant");
		mockMvc.perform(post("/api/v1/customer").contentType("application/json")
				.content(objectMapper.writeValueAsString(employee))).andExpect(status().isAccepted())
				.andExpect(jsonPath("$.empName").value("Nishant"));

	}

}
